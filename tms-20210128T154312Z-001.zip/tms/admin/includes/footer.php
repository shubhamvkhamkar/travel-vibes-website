<div class="copyrights">
	 <p>© 2019 Travel Vibes. All Rights Reserved |  <a href="#">Travel Vibes</a> </p>
</div>	
